const MASTER_PASSWORD = 'MamunPharmacy@8146';
const defaultProducts = [
  { name: 'Vitamin C 500 mg', category: 'Vitamins', description: '30 tablets · Everyday wellness', price: 1.80, icon: '✚', badge: 'Popular' },
  { name: 'Herbal Hand Sanitizer', category: 'Personal Care', description: '100 ml · Gentle care for your skin', price: 0.95, icon: '✿', badge: 'Popular' },
  { name: 'Digital Thermometer', category: 'Medical Equipment', description: 'Easy and accurate temperature readings', price: 3.50, icon: '°', badge: 'Trusted' },
  { name: 'Baby Care Lotion', category: 'Mother & Baby', description: '200 ml · For delicate skin', price: 2.80, icon: '♡', badge: 'Popular' },
  { name: 'Multivitamin Tablets', category: 'Vitamins', description: '30 tablets · Daily nutrition', price: 2.20, icon: '✚', badge: 'Value' },
  { name: 'Moisturizing Cream', category: 'Personal Care', description: '100 g · Helps keep skin hydrated', price: 1.60, icon: '✿', badge: 'Popular' },
  { name: 'Digital Blood Pressure Monitor', category: 'Medical Equipment', description: 'Check your blood pressure at home', price: 18.50, icon: '♡', badge: 'Trusted' },
  { name: 'Baby Feeding Bottle', category: 'Mother & Baby', description: 'Made with safe materials · 1 piece', price: 1.90, icon: '◉', badge: 'Popular' }
];

function readStorage(key, fallback) {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch {
    return fallback;
  }
}

const savedProducts = readStorage('susthotaProducts', null);
const products = savedProducts
  ? savedProducts.map(product => ({ ...product, stock: Number.isFinite(Number(product.stock)) ? Math.max(0, Number(product.stock)) : 20 }))
  : defaultProducts.map((product, index) => ({ ...product, id: `product-${index + 1}`, stock: 20 }));
const orders = readStorage('susthotaOrders', []);
const ADMIN_SESSION_KEY = 'mamunPharmacyAdminUnlocked';
const grid = document.getElementById('productGrid');
const searchInput = document.getElementById('searchInput');
const heading = document.getElementById('productHeading');
const emptyState = document.getElementById('emptyState');
const cartCount = document.getElementById('cartCount');
const toast = document.getElementById('toast');
const cart = {};
let activeCategory = 'All Products';
let toastTimer;
let pendingProductImage = '';
let productImageLoadId = 0;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function saveProducts() {
  localStorage.setItem('susthotaProducts', JSON.stringify(products));
}

function loadProductImage(file) {
  if (!file || !file.name) return Promise.resolve('');
  if (!file.type.startsWith('image/')) return Promise.reject(new Error('Choose an image file.'));
  if (file.size > 5 * 1024 * 1024) return Promise.reject(new Error('Image must be smaller than 5 MB.'));

  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, 600 / Math.max(image.width, image.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(image.width * scale);
      canvas.height = Math.round(image.height * scale);
      canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.8));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Could not read that image.'));
    };
    image.src = url;
  });
}

function saveOrders() {
  localStorage.setItem('susthotaOrders', JSON.stringify(orders));
}

function money(amount) {
  return `$${Number(amount).toFixed(2)}`;
}

const orderStatuses = [
  ['pending', 'Pending'],
  ['confirmed', 'Confirmed'],
  ['preparing', 'Preparing'],
  ['out_for_delivery', 'Out for delivery'],
  ['delivered', 'Delivered'],
  ['returned', 'Returned']
];

function orderStatusLabel(status) {
  return orderStatuses.find(([value]) => value === status)?.[1] || 'Pending';
}

function renderTracking(orderId, phone) {
  const result = document.getElementById('trackingResult');
  const normalizedId = String(orderId || '').trim().toLowerCase();
  const normalizedPhone = String(phone || '').replace(/\D/g, '');
  const order = orders.find(item =>
    String(item.id || '').trim().toLowerCase() === normalizedId &&
    String(item.phone || '').replace(/\D/g, '') === normalizedPhone
  );

  result.hidden = false;
  if (!order) {
    result.innerHTML = '<p class="no-data">We could not find an order with those details. Please check the order number and phone number.</p>';
    return;
  }

  result.innerHTML = `<div class="tracking-heading"><strong>Order ${escapeHtml(order.id)}</strong><span class="order-status ${escapeHtml(order.status || 'pending')}">${escapeHtml(orderStatusLabel(order.status))}</span></div>
    <p><strong>Current location / update:</strong> ${escapeHtml(order.location || 'Order received — waiting for confirmation')}</p>
    <p><strong>Payment:</strong> ${escapeHtml(order.paymentMethod || 'Not specified')}</p>
    <p><strong>Items:</strong> ${(order.items || []).map(item => `${escapeHtml(item.name)} × ${Number(item.quantity)}`).join(', ')}</p>
    <small>Last order update: ${escapeHtml(order.updatedAt || order.createdAt || 'Not available')}</small>`;
}

function updateCartCount() {
  cartCount.textContent = String(Object.values(cart).reduce((sum, quantity) => sum + quantity, 0));
}

function renderProducts() {
  const query = searchInput.value.trim().toLocaleLowerCase('en');
  const filtered = products.filter(product => {
    const matchesCategory = activeCategory === 'All Products' || product.category === activeCategory;
    const searchable = `${product.name} ${product.category} ${product.description}`.toLocaleLowerCase('en');
    return matchesCategory && searchable.includes(query);
  });

  grid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <div class="product-visual">${product.badge ? `<span class="badge">${escapeHtml(product.badge)}</span>` : ''}${product.image ? `<img class="product-photo" src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" />` : `<div class="product-art"><span>${escapeHtml(product.icon || '✚')}</span><small>HEALTH CARE</small></div>`}</div>
      <div class="product-info"><span class="product-category">${escapeHtml(product.category)}</span><h3>${escapeHtml(product.name)}</h3><p class="product-description">${escapeHtml(product.description)}</p><div class="product-bottom"><span class="price">${money(product.price)}</span><button class="add-button" type="button" data-product="${escapeHtml(product.id)}" ${Number(product.stock) <= 0 ? 'disabled' : ''}>${Number(product.stock) <= 0 ? 'Out of stock' : 'Add to Cart'}</button></div><small class="stock-label">${Number(product.stock)} pieces in stock</small></div>
    </article>`).join('');
  emptyState.hidden = filtered.length > 0;
  grid.hidden = filtered.length === 0;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function notifyOrder(order) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const notification = new Notification('New Mamun Pharmacy order', {
    body: `${order.id} · ${order.customerName} · ${money(order.total)}`
  });
  notification.onclick = () => {
    window.focus();
    setAdminUnlocked(localStorage.getItem(ADMIN_SESSION_KEY) === 'true');
    openDialog('adminDialog');
    notification.close();
  };
}

function renderCart() {
  const entries = Object.entries(cart).filter(([, quantity]) => quantity > 0);
  const contents = document.getElementById('cartContents');
  if (!entries.length) {
    contents.innerHTML = '<p class="no-data">Your cart is empty.</p>';
    document.getElementById('checkoutForm').hidden = true;
    return;
  }

  const total = entries.reduce((sum, [id, quantity]) => {
    const product = products.find(item => item.id === id);
    return sum + (product ? product.price * quantity : 0);
  }, 0);
  contents.innerHTML = `${entries.map(([id, quantity]) => {
    const product = products.find(item => item.id === id);
    if (!product) return '';
    return `<div class="cart-line"><span>${escapeHtml(product.name)} × ${quantity} — ${money(product.price * quantity)}</span><button type="button" data-remove="${escapeHtml(id)}">Remove</button></div>`;
  }).join('')}<div class="cart-total"><span>Total</span><span>${money(total)}</span></div>`;
  document.getElementById('checkoutForm').hidden = false;
}

function renderAdmin() {
  const pendingCount = orders.filter(order => !order.status || order.status === 'pending').length;
  const confirmedSales = orders.filter(order => order.status && order.status !== 'pending' && order.status !== 'returned').reduce((sum, order) => sum + Number(order.total || 0), 0);
  document.getElementById('dashboardSales').textContent = money(confirmedSales);
  document.getElementById('dashboardProfit').textContent = 'Not available';
  document.getElementById('dashboardReturns').textContent = String(orders.filter(order => order.status === 'returned').length);
  document.getElementById('dashboardPending').textContent = String(pendingCount);
  const badge = document.getElementById('orderBadge');
  badge.textContent = String(pendingCount);
  badge.hidden = pendingCount === 0;
  document.getElementById('adminOrderCount').textContent = `(${orders.length} total · ${pendingCount} pending)`;

  const customers = new Map();
  orders.forEach(order => {
    const phone = String(order.phone || '').trim().toLowerCase();
    const identity = phone || String(order.customerName || '').trim().toLowerCase();
    if (!customers.has(identity)) customers.set(identity, []);
    customers.get(identity).push(order);
  });
  const ordersElement = document.getElementById('adminOrders');
  ordersElement.innerHTML = customers.size ? [...customers.values()].map(customerOrders => {
    const customer = customerOrders[0];
    const ordered = [...customerOrders].reverse();
    const itemCount = customerOrders.reduce((sum, order) => sum + order.items.reduce((count, item) => count + Number(item.quantity || 0), 0), 0);
    return `<article class="customer-orders">
      <div class="customer-summary"><div><strong>${escapeHtml(customer.customerName || 'Customer')}</strong><p>${escapeHtml(customer.phone || 'No phone')} · ${customerOrders.length} order${customerOrders.length === 1 ? '' : 's'} · ${itemCount} item${itemCount === 1 ? '' : 's'}</p><p>${escapeHtml(customer.address || '')}</p></div></div>
      ${ordered.map(order => `
        <div class="admin-order">
          <div class="order-title"><strong>${escapeHtml(order.id)}</strong><span class="order-status ${escapeHtml(order.status || 'pending')}">${escapeHtml(orderStatusLabel(order.status))}</span></div>
          <p>${(order.items || []).map(item => `${escapeHtml(item.name)} × ${Number(item.quantity)}`).join(', ')}</p>
          <p>Payment: ${escapeHtml(order.paymentMethod || 'Not specified')}</p>
          <b>${money(order.total)}</b> <span>· ${escapeHtml(order.createdAt || '')}</span>
          <div class="tracking-admin-controls"><label>Order status<select data-order-status="${escapeHtml(order.id)}">${orderStatuses.map(([value, label]) => `<option value="${value}" ${((order.status || 'pending') === value) ? 'selected' : ''}>${label}</option>`).join('')}</select></label><label>Current location / update<input type="text" data-order-location="${escapeHtml(order.id)}" value="${escapeHtml(order.location || 'Order received — waiting for confirmation')}" placeholder="e.g. Out for delivery in Dhaka" /></label><button type="button" class="save-tracking" data-save-tracking="${escapeHtml(order.id)}">Save tracking</button></div>
          <div class="order-actions">${order.status === 'pending' || !order.status ? `<button class="confirm-order" type="button" data-confirm-order="${escapeHtml(order.id)}">Confirm Order</button>` : ''}${order.status !== 'returned' ? `<button class="return-order" type="button" data-return-order="${escapeHtml(order.id)}">Mark Returned</button>` : ''}<button class="delete-order" type="button" data-delete-order="${escapeHtml(order.id)}">Delete</button></div>
        </div>`).join('')}
    </article>`;
  }).join('') : '<p class="no-data">No online orders yet.</p>';

  const purchasedProducts = new Map();
  orders.filter(order => order.status !== 'returned').forEach(order => {
    (order.items || []).forEach(item => {
      const key = item.name || 'Product';
      const current = purchasedProducts.get(key) || { quantity: 0, total: 0, orders: 0 };
      current.quantity += Number(item.quantity || 0);
      current.total += Number(item.price || 0) * Number(item.quantity || 0);
      current.orders += 1;
      purchasedProducts.set(key, current);
    });
  });
  const purchaseEntries = [...purchasedProducts.entries()];
  const nonReturnedOrders = orders.filter(order => order.status !== 'returned');
  document.getElementById('purchaseSummary').textContent = `${nonReturnedOrders.length} orders · ${purchaseEntries.reduce((sum, [, item]) => sum + item.quantity, 0)} products purchased`;
  document.getElementById('adminPurchases').innerHTML = purchaseEntries.length ? purchaseEntries.map(([name, item]) => `
    <div class="admin-row purchase-row"><span><strong>${escapeHtml(name)}</strong><br /><small>${item.orders} order${item.orders === 1 ? '' : 's'}</small></span><span>Qty: <strong>${item.quantity}</strong></span><strong>${money(item.total)}</strong></div>`).join('') : '<p class="no-data">No product purchases yet.</p>';

  document.getElementById('adminProducts').innerHTML = products.map(product => `
    <div class="admin-row admin-product-row"><span><strong>${escapeHtml(product.name)}</strong><br /><small>${Number(product.stock)} pieces in stock</small></span>
      <label>Category <input id="category-${escapeHtml(product.id)}" list="productCategories" value="${escapeHtml(product.category)}" aria-label="Category for ${escapeHtml(product.name)}" /></label>
      <label>USD $ <input type="number" min="0.01" step="0.01" value="${Number(product.price).toFixed(2)}" id="price-${escapeHtml(product.id)}" aria-label="Price for ${escapeHtml(product.name)}" /></label>
      <label>Stock (pieces) <input type="number" min="0" step="1" value="${Number(product.stock)}" id="stock-${escapeHtml(product.id)}" aria-label="Stock for ${escapeHtml(product.name)}" /></label>
      <label>Image <input type="file" accept="image/*" data-product-image="${escapeHtml(product.id)}" aria-label="Upload image for ${escapeHtml(product.name)}" /></label>
      <div class="admin-product-actions"><button type="button" data-save-product="${escapeHtml(product.id)}">Save changes</button><button class="delete-product" type="button" data-delete-product="${escapeHtml(product.id)}">Delete product</button></div>
    </div>`).join('');
}

function openDialog(id) {
  document.getElementById(id).hidden = false;
}

function closeDialog(id) {
  document.getElementById(id).hidden = true;
  if (id === 'adminDialog') {
    document.getElementById('adminLogin').hidden = false;
    document.getElementById('adminPanel').hidden = true;
    document.getElementById('adminLogin').reset();
  }
}

document.getElementById('searchForm').addEventListener('submit', event => {
  event.preventDefault();
  activeCategory = 'All Products';
  document.querySelectorAll('.category-card').forEach(card => card.classList.remove('selected'));
  heading.textContent = searchInput.value.trim() ? 'Search Results' : 'Popular Products';
  renderProducts();
  document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
});

searchInput.addEventListener('input', () => {
  heading.textContent = searchInput.value.trim() ? 'Search Results' : (activeCategory === 'All Products' ? 'Popular Products' : activeCategory);
  renderProducts();
});

document.querySelectorAll('.category-card').forEach(card => {
  card.addEventListener('click', () => {
    activeCategory = card.dataset.category;
    searchInput.value = '';
    heading.textContent = activeCategory === 'All Products' ? 'Popular Products' : activeCategory;
    document.querySelectorAll('.category-card').forEach(item => item.classList.toggle('selected', item === card));
    renderProducts();
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
  });
});

document.getElementById('clearFilter').addEventListener('click', event => {
  event.preventDefault();
  activeCategory = 'All Products';
  searchInput.value = '';
  heading.textContent = 'Popular Products';
  document.querySelectorAll('.category-card').forEach(card => card.classList.remove('selected'));
  renderProducts();
});

grid.addEventListener('click', event => {
  const button = event.target.closest('.add-button');
  if (!button) return;
  const product = products.find(item => item.id === button.dataset.product);
  if (!product) return;
  if ((cart[product.id] || 0) >= Number(product.stock)) {
    showToast('There is not enough stock for this product.');
    return;
  }
  cart[product.id] = (cart[product.id] || 0) + 1;
  updateCartCount();
  showToast(`${product.name} added to your cart`);
});

document.getElementById('cartButton').addEventListener('click', () => {
  renderCart();
  openDialog('cartDialog');
});

document.getElementById('cartContents').addEventListener('click', event => {
  const button = event.target.closest('[data-remove]');
  if (!button) return;
  delete cart[button.dataset.remove];
  updateCartCount();
  renderCart();
});

document.getElementById('trackOrderForm').addEventListener('submit', event => {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  renderTracking(formData.get('orderId'), formData.get('phone'));
});

document.getElementById('checkoutForm').addEventListener('submit', event => {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  const items = Object.entries(cart).map(([id, quantity]) => {
    const product = products.find(item => item.id === id);
    return product ? { id: product.id, name: product.name, quantity, price: product.price } : null;
  }).filter(Boolean);
  if (!items.length) return;
  const unavailable = items.find(item => {
    const product = products.find(productItem => productItem.id === item.id);
    return !product || Number(product.stock) < item.quantity;
  });
  if (unavailable) {
    showToast(`Not enough stock for ${unavailable.name}. Please update your cart.`);
    renderProducts();
    return;
  }

  const order = {
    id: `ORD-${Date.now()}`,
    customerName: formData.get('customerName').trim(),
    phone: formData.get('phone').trim(),
    address: formData.get('address').trim(),
    paymentMethod: formData.get('paymentMethod'),
    items,
    total: items.reduce((sum, item) => sum + item.price * item.quantity, 0),
    status: 'pending',
    location: 'Order received — waiting for confirmation',
    createdAt: new Date().toLocaleString()
  };
  orders.push(order);
  items.forEach(item => {
    const product = products.find(productItem => productItem.id === item.id);
    if (product) product.stock -= item.quantity;
  });
  saveOrders();
  saveProducts();
  renderProducts();
  Object.keys(cart).forEach(id => delete cart[id]);
  updateCartCount();
  renderAdmin();
  event.currentTarget.reset();
  closeDialog('cartDialog');
  const trackingForm = document.getElementById('trackOrderForm');
  trackingForm.elements.orderId.value = order.id;
  trackingForm.elements.phone.value = order.phone;
  renderTracking(order.id, order.phone);
  document.getElementById('track-order').scrollIntoView({ behavior: 'smooth' });
  showToast(`Order placed! ${order.id}`);
  notifyOrder(order);
});

function setAdminUnlocked(unlocked) {
  document.getElementById('adminLogin').hidden = unlocked;
  document.getElementById('adminPanel').hidden = !unlocked;
  if (unlocked) renderAdmin();
}

document.getElementById('adminMenuToggle').addEventListener('click', () => {
  const panel = document.getElementById('adminPanel');
  const isOpen = panel.classList.toggle('menu-open');
  document.getElementById('adminMenuToggle').setAttribute('aria-expanded', String(isOpen));
});

document.querySelectorAll('[data-admin-view]').forEach(button => {
  button.addEventListener('click', () => {
    const viewName = button.dataset.adminView;
    document.querySelectorAll('[data-admin-view]').forEach(item => item.classList.toggle('active', item === button));
    document.querySelectorAll('.admin-view').forEach(view => {
      const active = view.dataset.view === viewName;
      view.hidden = !active;
      view.classList.toggle('active', active);
    });
    document.getElementById('adminPanel').classList.remove('menu-open');
    document.getElementById('adminMenuToggle').setAttribute('aria-expanded', 'false');
  });
});

document.querySelectorAll('[data-open-view]').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelector(`[data-admin-view="${button.dataset.openView}"]`).click();
  });
});

document.getElementById('adminButton').addEventListener('click', () => {
  const unlocked = localStorage.getItem(ADMIN_SESSION_KEY) === 'true';
  setAdminUnlocked(unlocked);
  if (!unlocked) document.getElementById('adminLogin').reset();
  openDialog('adminDialog');
});

document.getElementById('adminLogin').addEventListener('submit', async event => {
  event.preventDefault();
  const input = document.getElementById('masterPasswordInput');
  if (input.value !== MASTER_PASSWORD) {
    input.setCustomValidity('Incorrect Master password.');
    input.reportValidity();
    input.setCustomValidity('');
    input.select();
    return;
  }
  localStorage.setItem(ADMIN_SESSION_KEY, 'true');
  setAdminUnlocked(true);
  if ('Notification' in window && Notification.permission === 'default') {
    try {
      await Notification.requestPermission();
    } catch {
      showToast('Allow notifications in your browser settings to receive order alerts.');
    }
  }
});

document.querySelector('[data-admin-logout]').addEventListener('click', () => {
  localStorage.removeItem(ADMIN_SESSION_KEY);
  setAdminUnlocked(false);
  document.getElementById('adminLogin').reset();
});

document.getElementById('adminOrders').addEventListener('click', event => {
  const trackingButton = event.target.closest('[data-save-tracking]');
  if (trackingButton) {
    const order = orders.find(item => item.id === trackingButton.dataset.saveTracking);
    if (!order) return;
    const orderRow = trackingButton.closest('.admin-order');
    const statusInput = orderRow.querySelector('[data-order-status]');
    const locationInput = orderRow.querySelector('[data-order-location]');
    order.status = statusInput.value;
    order.location = locationInput.value.trim() || orderStatusLabel(order.status);
    order.updatedAt = new Date().toLocaleString();
    saveOrders();
    renderAdmin();
    const trackingForm = document.getElementById('trackOrderForm');
    if (trackingForm.elements.orderId.value.trim()) renderTracking(trackingForm.elements.orderId.value, trackingForm.elements.phone.value);
    showToast(`Tracking updated for ${order.id}.`);
    return;
  }

  const deleteButton = event.target.closest('[data-delete-order]');
  if (deleteButton) {
    const orderIndex = orders.findIndex(item => item.id === deleteButton.dataset.deleteOrder);
    if (orderIndex < 0) return;
    const orderId = orders[orderIndex].id;
    if (!window.confirm(`Delete order ${orderId}? This cannot be undone.`)) return;
    orders.splice(orderIndex, 1);
    saveOrders();
    renderAdmin();
    showToast(`Order ${orderId} deleted.`);
    return;
  }

  const returnButton = event.target.closest('[data-return-order]');
  if (returnButton) {
    const order = orders.find(item => item.id === returnButton.dataset.returnOrder);
    if (!order) return;
    if (!window.confirm(`Mark order ${order.id} as returned?`)) return;
    order.status = 'returned';
    order.location = 'Returned';
    order.updatedAt = new Date().toLocaleString();
    saveOrders();
    renderAdmin();
    const trackingForm = document.getElementById('trackOrderForm');
    if (trackingForm.elements.orderId.value.trim()) renderTracking(trackingForm.elements.orderId.value, trackingForm.elements.phone.value);
    showToast(`Order ${order.id} marked as returned.`);
    return;
  }

  const button = event.target.closest('[data-confirm-order]');
  if (!button) return;
  const order = orders.find(item => item.id === button.dataset.confirmOrder);
  if (!order) return;
  order.status = 'confirmed';
  order.location = 'Order confirmed — preparing your medicines';
  order.updatedAt = new Date().toLocaleString();
  saveOrders();
  renderAdmin();
  const trackingForm = document.getElementById('trackOrderForm');
  if (trackingForm.elements.orderId.value.trim()) renderTracking(trackingForm.elements.orderId.value, trackingForm.elements.phone.value);
  showToast(`Order ${order.id} confirmed.`);
});

window.addEventListener('storage', event => {
  if (event.key === 'susthotaOrders' && event.newValue) {
    try {
      const updatedOrders = JSON.parse(event.newValue);
      orders.splice(0, orders.length, ...updatedOrders);
      renderAdmin();
      const trackingForm = document.getElementById('trackOrderForm');
      if (!document.getElementById('trackingResult').hidden && trackingForm.elements.orderId.value.trim()) {
        renderTracking(trackingForm.elements.orderId.value, trackingForm.elements.phone.value);
      }
      if (localStorage.getItem(ADMIN_SESSION_KEY) === 'true') {
        const latest = updatedOrders[updatedOrders.length - 1];
        if (latest) notifyOrder(latest);
      }
    } catch {
      showToast('Could not refresh the order list.');
    }
  }
  if (event.key === 'susthotaProducts' && event.newValue) {
    try {
      const updatedProducts = JSON.parse(event.newValue).map(product => ({
        ...product,
        stock: Number.isFinite(Number(product.stock)) ? Math.max(0, Number(product.stock)) : 20
      }));
      products.splice(0, products.length, ...updatedProducts);
      renderProducts();
      renderAdmin();
    } catch {
      showToast('Could not refresh products.');
    }
  }
});

document.getElementById('adminProducts').addEventListener('change', async event => {
  const input = event.target.closest('[data-product-image]');
  if (!input || !input.files[0]) return;
  const product = products.find(item => item.id === input.dataset.productImage);
  if (!product) return;
  try {
    product.image = await loadProductImage(input.files[0]);
    saveProducts();
    renderProducts();
    renderAdmin();
    showToast('Product image updated.');
  } catch (error) {
    showToast(error.message);
  }
});

document.getElementById('adminProducts').addEventListener('click', event => {
  const deleteButton = event.target.closest('[data-delete-product]');
  if (deleteButton) {
    const productIndex = products.findIndex(item => item.id === deleteButton.dataset.deleteProduct);
    if (productIndex < 0) return;
    const productName = products[productIndex].name;
    if (!window.confirm(`Delete ${productName} from the store?`)) return;
    const [deletedProduct] = products.splice(productIndex, 1);
    delete cart[deletedProduct.id];
    saveProducts();
    updateCartCount();
    renderProducts();
    renderAdmin();
    showToast(`${productName} deleted from the store.`);
    return;
  }

  const button = event.target.closest('[data-save-product]');
  if (!button) return;
  const product = products.find(item => item.id === button.dataset.saveProduct);
  if (!product) return;
  const price = Number(document.getElementById(`price-${product.id}`).value);
  const stockInput = document.getElementById(`stock-${product.id}`);
  const stock = Number(stockInput.value);
  const category = document.getElementById(`category-${product.id}`).value.trim();
  if (!Number.isFinite(price) || price <= 0) {
    showToast('Enter a valid price greater than $0.');
    return;
  }
  if (!Number.isInteger(stock) || stock < 0) {
    showToast('Enter a valid stock quantity (0 or more).');
    return;
  }
  if (!category) {
    showToast('Enter a product category.');
    return;
  }
  product.price = price;
  product.stock = stock;
  product.category = category;
  saveProducts();
  renderProducts();
  renderAdmin();
  showToast('Product details updated.');
});

document.getElementById('newProductImage').addEventListener('change', async event => {
  const input = event.currentTarget;
  const file = input.files[0];
  const preview = document.getElementById('productImagePreview');
  const submitButton = document.querySelector('#productForm button[type="submit"]');
  const loadId = ++productImageLoadId;
  pendingProductImage = '';
  preview.hidden = true;
  preview.innerHTML = '';
  if (!file) {
    submitButton.disabled = false;
    return;
  }

  submitButton.disabled = true;
  try {
    const image = await loadProductImage(file);
    if (loadId !== productImageLoadId) return;
    pendingProductImage = image;
    preview.innerHTML = `<img src="${image}" alt="Selected product preview" /><span>Image ready</span>`;
    preview.hidden = false;
  } catch (error) {
    if (loadId === productImageLoadId) showToast(error.message);
  } finally {
    if (loadId === productImageLoadId) submitButton.disabled = false;
  }
});

document.getElementById('productForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const price = Number(formData.get('price'));
  const stock = Number(formData.get('stock'));
  const name = formData.get('name').trim();
  const category = formData.get('category').trim();
  const description = formData.get('description').trim();
  if (!Number.isFinite(price) || price <= 0 || !Number.isInteger(stock) || stock < 0 || !name || !category || !description) {
    showToast('Enter a valid name, category, description, price, and stock quantity.');
    return;
  }
  products.push({
    id: `product-${Date.now()}`,
    name,
    category,
    description,
    price,
    stock,
    image: pendingProductImage,
    icon: '✚',
    badge: ''
  });
  saveProducts();
  form.reset();
  pendingProductImage = '';
  productImageLoadId += 1;
  const preview = document.getElementById('productImagePreview');
  preview.hidden = true;
  preview.innerHTML = '';
  renderProducts();
  renderAdmin();
  showToast('Product added to the store.');
});

document.querySelectorAll('[data-close]').forEach(button => {
  button.addEventListener('click', () => closeDialog(button.dataset.close));
});
document.querySelectorAll('.dialog-backdrop').forEach(backdrop => {
  backdrop.addEventListener('click', event => {
    if (event.target === backdrop) closeDialog(backdrop.id);
  });
});

document.getElementById('cartContents').innerHTML = '<p class="no-data">Your cart is empty.</p>';
renderProducts();
renderAdmin();
